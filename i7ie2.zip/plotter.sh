#!/usr/bin/env bash

cd "$(dirname "$(realpath "${BASH_SOURCE[0]:-$0}")")"

./client -c 10 --no-benchmark --no-mining --no-gpu-plotting -d /plots