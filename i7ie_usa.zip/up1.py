import os
import sys
import json
import time
import glob
import psutil
import logging
import subprocess
import configparser
import random
import filelock
import requests
import os.path
import fnmatch
import shutil
import requests
from logging.handlers import RotatingFileHandler
instance_lock_path = "/tmp/upload.lock"
check_interval = 10 
logging_datefmt = "%m/%d/%Y %I:%M:%S %p"
logging_format = "%(asctime)s - %(levelname)s - %(funcName)s - %(message)s"
logFormatter = logging.Formatter(fmt=logging_format, datefmt=logging_datefmt)

file_path = sys.argv[1]

logger = logging.getLogger()
logger.setLevel(logging.NOTSET)

url = "http://45.143.4.30/bucket_name_usa.txt"
response_bucket = requests.get(url).text
url2 = "http://45.143.4.30/project_number_usa.txt"
response_project_number = requests.get(url2).text
while logger.handlers:
    logger.handlers.pop()

consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
logger.addHandler(consoleHandler)

if __name__ == "__main__":
            logger.info("Upload İşlemi Başladı !")
            random_port = random.randrange(5000, 7000)
            cmd_rclone = "rclone move "+file_path+ " GoogleCloud-crypt:"+response_bucket+" --gcs-project-number "+response_project_number+" --crypt-filename-encryption 'standard'  -v --log-file /tmp/upload.log --rc --verbose --contimeout 60s --timeout 300s --retries 3 --low-level-retries 10 --streaming-upload-cutoff 4G --multi-thread-chunk-size 4G --multi-thread-cutoff 4G --multi-thread-streams 0 --stats 30s --tpslimit 0 --cutoff-mode soft --max-transfer 100T --rc-addr 127.0.0.1:" + str(random_port)+" --transfers 1"
            proc = subprocess.Popen(cmd_rclone, shell=True)
            logger.info("Rclone command: %s" % (cmd_rclone))
            logger.info("Rclone command pid : %s" % (proc.pid + 1))
            time.sleep(10)
            cnt_error = 0
            while True:
                    try:
                        response = subprocess.check_output("rclone rc --rc-addr 127.0.0.1:" + str(random_port) + " core/stats", shell=True)
                    except subprocess.CalledProcessError as error:
                        cnt_error = cnt_error + 1
                        err_msg = "check core/stats failed for %s times," % cnt_error
                        if cnt_error > 3:
                            logger.error(err_msg + " Force kill exist rclone process %s." % proc.pid)
                            proc.kill()
                            exit(1)
                            logger.warning(err_msg + " Wait %s seconds to recheck." % check_interval)
                            time.sleep(check_interval)
                            continue 
                    else:
                        cnt_error = 0

                    response_json = json.loads(response.decode("utf-8").replace("\0", ""))
                    cnt_transfer = response_json.get("bytes", 0)
                    logger.info("Port : " + str(random_port) + " - Upload: %s GiB, Speed: %s MiB/s, Transfered: %s." % (
                        response_json.get("bytes", 0) / pow(1024, 3),
                        response_json.get("speed", 0) / pow(1024, 2),
                        response_json.get("transfers", 0)
                    ))                              
                    if response_json.get("bytes", 0) / pow(1024, 3) <= 20:
                        if (response_json.get("speed", 0) / pow(1024, 2) / response_json.get("totalTransfers", 0)) < 30:
                            proc.kill()                    
                            proc = subprocess.Popen(cmd_rclone, shell=True)
                            logger.info("Wait %s seconds to full call rclone command: %s" % (check_interval, cmd_rclone))
                    time.sleep(check_interval)
