while true; do
    file_count=$(find /plots -type f -name "*.fpt" | wc -l)
    
    # Eğer dosya sayısı 6'dan azsa scripti çalıştırma
    if [[ $file_count -lt 2 ]]; then
        echo "Yeterli dosya yok. Mevcut dosya sayısı: $file_count"
        sleep 10  # 10 saniye bekle ve tekrar kontrol et
        continue
    fi
    # Sayacı başlat
    counter=0
    
    # /plots klasöründe .fpt dosyalarını bul
    for file in /plots/*.fpt; do
        # Eğer dosya mevcutsa
        if [[ -f "$file" ]]; then
            # Sayaç 6'ya ulaştıysa döngüyü sonlandır
            if [[ $counter -ge 2 ]]; then
                break
            fi

            # Python scriptini arka planda çalıştır
            python3 up1.py "$file" &

            # Sayacı artır
            ((counter++))
        fi
    done
    
    # Tüm Python scriptlerinin tamamlanmasını bekle
    wait
    
    # Scripti yeniden başlatmadan önce bir süre beklemek isterseniz
    # sleep 5  # 5 saniye bekler
done
